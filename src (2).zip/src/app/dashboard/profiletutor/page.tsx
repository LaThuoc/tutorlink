'use client';

import React, { useState, useEffect, useCallback, useActionState } from 'react';
import TutorDashboardHeader from '@/src/app/_components/dashboard/tutor/TutorDashboardHeader';
import TutorDashboardSidebar from '@/src/app/_components/dashboard/tutor/TutorDashboardSidebar';
import TutorProfileWizard, { TutorProfileFullData } from './_components/TutorProfileWizard';
import TutorProfileSubmittedView, { ProfileStatus } from './_components/TutorProfileSubmittedView';
import { updateTutorProfile } from '@/src/modules/tutor/tutor';
import { createClient } from '@/src/lib/supabase/client';

// Hàm bóc tách JSON mảng an toàn, giải quyết triệt để lỗi dính raw JSON
function safeParseArray<T = unknown>(val: unknown): T[] {
  if (!val) return [];
  let parsed = val;
  if (typeof parsed === 'string') {
    try {
      parsed = JSON.parse(parsed);
    } catch {
      return [];
    }
  }
  if (Array.isArray(parsed)) {
    if (parsed.length === 1 && typeof parsed[0] === 'string' && parsed[0].startsWith('[')) {
      try {
        parsed = JSON.parse(parsed[0]);
      } catch {
        // Giữ nguyên
      }
    }
    return Array.isArray(parsed) ? (parsed as T[]) : [];
  }
  return [];
}

export default function TutorProfilePage() {
  const [state, formAction, isPending] = useActionState(updateTutorProfile, null);
  const [loading, setLoading] = useState<boolean>(true);
  const [status, setStatus] = useState<ProfileStatus>('pending');

  // Khởi tạo state RỖNG HOÀN TOÀN cho Form Wizard - Không tự điền sẵn dữ liệu cũ
  const [profileData, setProfileData] = useState<TutorProfileFullData>({
    avatarUrl: '',
    fullName: '',
    gender: 'Nam',
    dateOfBirth: '',
    phone: '',
    province: '',
    district: '',
    address: '',
    headline: '',
    bio: '',
    quote: '',
    schoolName: '',
    education: '',
    hourlyRate: '',
    teachingAreas: [],
    teachingModes: ['Dạy Online', 'Dạy Offline'],
    skills: [],
    achievements: [],
    subjectDetails: [],
    educations: [],
    certificates: [],
    experiences: [],
    isCompleted: false,
  });

  const fetchProfileData = useCallback(async () => {
    const supabase = createClient();
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: tut } = await supabase
        .from('tutor_profiles')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (tut?.status) {
        setStatus(tut.status as ProfileStatus);
      }

      const isCompleted = Boolean(tut?.is_completed || (tut?.headline && tut?.subject_details?.length > 0));

      // CHỈ NẠP DỮ LIỆU KHI HỒ SƠ ĐÃ HOÀN THÀNH/ĐÃ NỘP TRONG DATABASE
      if (tut && isCompleted) {
        setProfileData({
          avatarUrl: tut.avatar_url || '',
          fullName: tut.full_name || '',
          gender: tut.gender || 'Nam',
          dateOfBirth: tut.date_of_birth || '',
          phone: tut.phone || '',
          province: tut.province || '',
          district: tut.district || '',
          address: tut.address || '',
          headline: tut.headline || '',
          bio: tut.bio || '',
          quote: tut.quote || '',
          schoolName: tut.school_name || '',
          education: tut.education || '',
          hourlyRate: tut.hourly_rate || '',
          teachingAreas: safeParseArray<string>(tut.teaching_areas),
          teachingModes: safeParseArray<string>(tut.teaching_modes).length > 0 
            ? safeParseArray<string>(tut.teaching_modes) 
            : ['Dạy Online', 'Dạy Offline'],
          skills: safeParseArray<string>(tut.skills),
          achievements: safeParseArray<string>(tut.achievements),
          subjectDetails: safeParseArray(tut.subject_details),
          educations: safeParseArray(tut.educations),
          certificates: safeParseArray(tut.certificates_data ?? tut.certificates),
          experiences: safeParseArray(tut.experiences),
          isCompleted: true,
        });
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchProfileData();
  }, [fetchProfileData]);

  // Nạp lại dữ liệu chuẩn từ DB ngay lập tức khi Submit thành công
  useEffect(() => {
    if (state?.success) {
      fetchProfileData();
    }
  }, [state?.success, fetchProfileData]);

  const isSubmitted = profileData.isCompleted || Boolean(state?.success && state?.isCompleted);

  if (loading) {
    return (
      <div className="min-h-screen grid place-items-center bg-slate-50 text-xs font-bold text-slate-500">
        Đang tải dữ liệu hồ sơ gia sư...
      </div>
    );
  }

  return (
    <div className="min-h-screen w-full bg-slate-50/60 text-slate-800 font-sans">
      <TutorDashboardHeader />
      <div className="flex w-full">
        <TutorDashboardSidebar />
        <main className="flex-1 p-4 lg:p-6">
          {!isSubmitted ? (
            <TutorProfileWizard 
              data={profileData} 
              formAction={formAction} 
              isPending={isPending} 
              state={state} 
            />
          ) : (
            <TutorProfileSubmittedView 
              key={profileData.phone || profileData.fullName || 'tutor-view'} 
              data={profileData} 
              status={status} 
            />
          )}
        </main>
      </div>
    </div>
  );
}